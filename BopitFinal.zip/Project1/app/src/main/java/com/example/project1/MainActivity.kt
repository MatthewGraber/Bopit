//
//References:
//https://developer.android.com/guide/topics/sensors/sensors_motion
//

//LOG:
// 02122023 - This has the initial config for working with accel to determine if shaking.
// 02132023 - Added in switching between shaking and bopping.
// 02222023 - Twisting and shaking separated and bopping updated with multicolors

package com.example.project1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val pb = findViewById<Button>(R.id.playbutton)
        pb.setOnClickListener(this)
        val qb2 = findViewById<Button>(R.id.quitbutton)
        qb2.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        val intent = Intent(this, Game::class.java)
        if (p0 != null) {
            if (p0.id==R.id.playbutton)
            {
                startActivity(intent)
                this@MainActivity.finish()
                exitProcess(0)
            }
            if (p0.id==R.id.quitbutton)
            {
                this@MainActivity.finish()
                exitProcess(0)
            }
        }
    }
}