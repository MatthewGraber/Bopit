package com.example.project1

//
//References:
//https://developer.android.com/guide/topics/sensors/sensors_motion
//https://medium.com/@olajhidey/working-with-countdown-timer-in-android-studio-using-kotlin-39fd7826e205
//https://stackoverflow.com/questions/47001467/how-to-use-settextcolorhexavalue-on-kotlin-for-android
//https://www.geeksforgeeks.org/android-sensors-with-example/
//https://developer.android.com/guide/topics/sensors/sensors_position
//https://developer.android.com/guide/topics/sensors/sensors_motion
//https://developer.android.com/reference/android/hardware/SensorEvent#sensor
//https://developer.android.com/reference/android/hardware/Sensor
//https://developer.android.com/reference/android/hardware/SensorManager
//https://www.geeksforgeeks.org/how-to-detect-shake-event-in-android/
//https://stackoverflow.com/questions/14574879/how-to-detect-movement-of-an-android-device
//

//LOG:
// 02122023 - This has the initial config for working with accel to determine if shaking.
// 02132023 - Added in switching between shaking and bopping.
// 02222023 - Twisting and shaking separated and bopping updated with multicolors
// 03152023 - Works

import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaPlayer
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.sqrt
import kotlin.system.exitProcess


class Game : AppCompatActivity(), SensorEventListener, View.OnClickListener
{
    //variable for sensor
    private lateinit var sensorManager: SensorManager
    //variables for shake it
    var accel = 0f
    var curraccel = 0f
    var prevaccel = 0f
    //variables for twist it
    private val accelerometerReading = FloatArray(3)
    private val magnetometerReading = FloatArray(3)
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    var preOr = 0f
    var CurrOr = 0f
    var rotdeg: Double = 0.0
    val shakeThreshold = 10.0f;

    //variables for textbox
    private lateinit var comm: TextView
    //variable for scoring
    var score = 0;
    //variables for timer
    lateinit var gametimer: CountDownTimer
    var START_MILLI_SECONDS = 10000L
    var isRunning: Boolean = false;
    var time_in_milli_seconds = 0L
    var cycles = 0;

    // Sound players
    var mMediaPlayer: MediaPlayer? = null
    var backgroundPlayer: MediaPlayer? = null;

    val backgroundVol = 0.4F;
    val effectVol = 1.0F;

    // Sound resources


//    val twistSound = resources.getIdentifier(
//        R.raw.twistit.toString(),
//        "raw", packageName)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        comm = findViewById < TextView >(R.id.textView)

        val rbutton = findViewById<Button>(R.id.redbutton)
        rbutton.setOnClickListener(this)
        val ybutton = findViewById<Button>(R.id.yellowbutton)
        ybutton.setOnClickListener(this)
        val gbutton = findViewById<Button>(R.id.greenbutton)
        gbutton.setOnClickListener(this)
        val bbutton = findViewById<Button>(R.id.bluebutton)
        bbutton.setOnClickListener(this)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        senACC = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        senMag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        // Begin the background music
        val backgroundMusic = resources.getIdentifier(
            R.raw.background.toString(), "raw", packageName)
        backgroundPlayer = MediaPlayer.create(this, backgroundMusic)
        backgroundPlayer?.setVolume(backgroundVol, backgroundVol)
        backgroundPlayer!!.isLooping = true;
        backgroundPlayer!!.start();

        RegSen()
        playGame(START_MILLI_SECONDS)
    }

    private var senACC: Sensor? = null
    private var senMag: Sensor? = null
    fun RegSen() {
        sensorManager.registerListener(this,senACC,SensorManager.SENSOR_DELAY_GAME)
        sensorManager.registerListener(this, senMag, SensorManager.SENSOR_DELAY_FASTEST,
            SensorManager.SENSOR_DELAY_FASTEST)
    }
    var i: Int = 1
    private fun randomize() {
        if(i == 1)
        {
            BopIt()
            i++
        }
        else{
            var rand = (0..2).random()
            if(rand == 0){
                comm.text = "Twist It"
                val twistSound = resources.getIdentifier(
                    R.raw.twistit.toString(), "raw", packageName)
                mMediaPlayer = MediaPlayer.create(this, twistSound)
                mMediaPlayer?.setVolume(effectVol, effectVol)
                mMediaPlayer!!.start();

            }
            else if(rand==1){BopIt()}
            else{
                comm.text = "Shake It"
                val shakeSound = resources.getIdentifier(
                    R.raw.shakeit.toString(), "raw", packageName)
                mMediaPlayer = MediaPlayer.create(this, shakeSound)
                mMediaPlayer?.setVolume(effectVol, effectVol)
                mMediaPlayer!!.start();
            }
        }
        cycles++;
        if (cycles % 5 == 0) {
            START_MILLI_SECONDS = (START_MILLI_SECONDS*0.9).toLong();
        }
    }

    private lateinit var color: String
    private fun BopIt() {
        color = arrayOf("red", "blue", "green", "yellow").random()

        // Color sounds
        val blueSound = resources.getIdentifier(
            R.raw.blue.toString(),
            "raw", packageName)
        val greenSound = resources.getIdentifier(
            R.raw.green.toString(),
            "raw", packageName)
        val redSound = resources.getIdentifier(
            R.raw.red.toString(),
            "raw", packageName)
        val yellowSound = resources.getIdentifier(
            R.raw.yellow.toString(),
            "raw", packageName)
        val fanfare = resources.getIdentifier(
            R.raw.fanfare.toString(),
            "raw", packageName)
        val soundMap = mapOf("red" to redSound, "blue" to blueSound, "green" to greenSound, "yellow" to yellowSound)
        mMediaPlayer = soundMap[color]?.let { MediaPlayer.create(this, it) }
        mMediaPlayer?.setVolume(effectVol, effectVol)
        mMediaPlayer!!.start();

        var task = "Bop It: $color"
        comm.text = task
    }
    override fun onClick(v:View) {
        if(v.id==R.id.bluebutton && color == "blue" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            score++
            comm.setTextColor(Color.parseColor("#FF008000"))
            playGame(START_MILLI_SECONDS)
        }
        else if(v.id==R.id.bluebutton && color != "blue" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            endGame()
        }
        else if(v.id==R.id.redbutton && color == "red" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            score++
            comm.setTextColor(Color.parseColor("#FF008000"))
            playGame(START_MILLI_SECONDS)
        }
        else if(v.id==R.id.redbutton && color != "red" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            endGame()
        }
        else if(v.id==R.id.yellowbutton && color == "yellow" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            score++
            comm.setTextColor(Color.parseColor("#FF008000"))
            playGame(START_MILLI_SECONDS)
        }
        else if(v.id==R.id.yellowbutton && color != "yellow" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            endGame()
        }
        else if(v.id==R.id.greenbutton && color == "green" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            score++
            comm.setTextColor(Color.parseColor("#FF008000"))
            playGame(START_MILLI_SECONDS)
        }
        else if(v.id==R.id.greenbutton && color != "green" && comm.text == "Bop It: $color"){
            gametimer.cancel()
            isRunning = false
            endGame()
        }
        else
        {
            gametimer.cancel()
            isRunning = false
            endGame()
        }
    }

    private fun ShakeIt() {
        accel = shakeThreshold
        curraccel = SensorManager.GRAVITY_EARTH
        prevaccel = SensorManager.GRAVITY_EARTH
    }
    override fun onSensorChanged(event:SensorEvent) {
        var rotdeg: Double = 0.0

        if(event.sensor.type == Sensor.TYPE_ACCELEROMETER){
            //code for twist it
            System.arraycopy(event.values, 0, accelerometerReading, 0, accelerometerReading.size)

            //code for shake it
            prevaccel = curraccel
            val x = event.values[0] //Accel F along x axis (including gravity)
            val y = event.values[1] //Accel F along y axis (including gravity)
            val z = event.values[2] //Accel F along z axis (including gravity)
            curraccel = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
            accel = accel * 0.9f + (curraccel - prevaccel)
        }
        else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(event.values, 0, magnetometerReading, 0, magnetometerReading.size)
        }

        //code for twist it
        preOr = CurrOr
        SensorManager.getRotationMatrix(rotationMatrix, null, accelerometerReading, magnetometerReading)
        SensorManager.getOrientation(rotationMatrix, orientationAngles)
        CurrOr = orientationAngles[0]*orientationAngles[0]+
                orientationAngles[1]* orientationAngles[1]+
                orientationAngles[2]*orientationAngles[2]
        rotdeg = Math.abs(Math.toDegrees((CurrOr-preOr).toDouble()))

        if(comm.text == "Shake It" && accel > shakeThreshold && rotdeg < 135 && isRunning){
            gametimer.cancel()
            isRunning = false
            score++
            comm.setTextColor(Color.parseColor("#FF008000"))
            playGame(START_MILLI_SECONDS)
        }
        else if(comm.text == "Shake It" && rotdeg > 180 && isRunning){
            isRunning = false
            gametimer.cancel()
            comm.text = "Shake end $rotdeg"
            endGame()
        }
        else if(comm.text == "Twist It" && accel < shakeThreshold && rotdeg > 135 && isRunning){
            gametimer.cancel()
            isRunning = false
            score++
            comm.setTextColor(Color.parseColor("#FF008000"))
            playGame(START_MILLI_SECONDS)
        }
        else if(comm.text == "Twist It" && accel > shakeThreshold && isRunning){
            gametimer.cancel()
            isRunning = false
            comm.text = "Twist end"
            endGame()
        }
    }
    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {}

    fun playGame(time_in_seconds: Long) {
        Handler(Looper.getMainLooper()).postDelayed({
            randomize()
            comm.setTextColor(Color.parseColor("#FF000000"))
            // TODO: Play the correct sound
            gametimer = object : CountDownTimer(time_in_seconds, 100) {
                override fun onTick(millisUntilFinished: Long) {
                    time_in_milli_seconds = millisUntilFinished
                }
                override fun onFinish() {
                    endGame()
                }
            }
            gametimer.start()
            isRunning = true
        }, 2000)
    }
    fun endGame() {
        val intent = Intent(this, EndActivity::class.java)
        intent.putExtra("Score", score.toString());
        startActivity(intent)
        this@Game.finish()
        exitProcess(0)
    }
}