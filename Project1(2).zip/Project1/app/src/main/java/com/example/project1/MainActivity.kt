package com.example.project1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private var score = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)
        val pb = findViewById<Button>(R.id.button2)
        pb.setOnClickListener(this)
        val qb2 = findViewById<Button>(R.id.button3)
        qb2.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        val intent = Intent(this, End::class.java)
        if (p0 != null) {
            if (p0.id==R.id.button2)
            {
                startActivity(intent)
                this@MainActivity.finish()
                exitProcess(0)
            }
            if (p0.id==R.id.button3)
            {
                this@MainActivity.finish()
                exitProcess(0)
            }
        }
    }
}