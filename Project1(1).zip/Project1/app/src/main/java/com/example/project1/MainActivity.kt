package com.example.project1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlin.system.exitProcess

class Start : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)
        val pb = findViewById<Button>(R.id.button2)
        pb.setOnClickListener(this)
        val qb2 = findViewById<Button>(R.id.button3)
        qb2.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        if (p0 != null) {
            if (p0.id==R.id.button2)
            {

            }
            if (p0.id==R.id.button3)
            {
                this@Start.finish()
                exitProcess(0)
            }
        }
    }
}