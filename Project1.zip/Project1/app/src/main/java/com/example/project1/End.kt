package com.example.project1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlin.system.exitProcess

class End : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end)
        val qb = findViewById<Button>(R.id.button)
        qb.setOnClickListener(this)
        
    }

    override fun onClick(p0: View?) {
        if (p0 != null) {
            if(p0.id==R.id.button)
            {
                this@End.finish()
                exitProcess(0)
            }

        }
    }
}