package com.example.project1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlin.system.exitProcess

class EndActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end)
        val qb = findViewById<Button>(R.id.button)
        qb.setOnClickListener(this)
        val stb = findViewById<TextView>(R.id.textView_score)
        stb.text = "Score= "+ intent.getStringExtra("Score")
    }

    override fun onClick(p0: View?) {
        if (p0 != null) {
            if(p0.id==R.id.button)
            {
                this@EndActivity.finish()
                exitProcess(0)
            }
        }
    }
}

